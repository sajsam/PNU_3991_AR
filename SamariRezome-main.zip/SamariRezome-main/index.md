
### Sajedeh Samari


### Personal informations

---
+ name: Sajedeh
+ last name : Samari
+ Date of birth : 2000 / February / 21
+ I am a computer engineering student
+ location : Tehran , I.R.Iran


### Skill Highlights

---
+ Web programmer


### Education

---
+ Bachelor of science : Software Engineer
_ payam Noor University of North 

### language

---
+ Persian
+ English

### Favorites

---
+ Website programming
+ travel 
+ playing volleyball
+ 

### working Experience

---
+ Collaborate with a programming team in the form of a web programming project



--- 
### [رزومه فارسی](resume-fa.md)
